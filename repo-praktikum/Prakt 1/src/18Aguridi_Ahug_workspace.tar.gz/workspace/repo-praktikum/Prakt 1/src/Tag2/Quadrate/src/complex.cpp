#include "complex.h"

complex::complex()
{
    //ctor
}

complex::~complex()
{
    //dtor
}
