#ifndef COMPLEX_H
#define COMPLEX_H


class complex
{
    public:
        complex();
        virtual ~complex();

    protected:

    private:
};

#endif // COMPLEX_H
