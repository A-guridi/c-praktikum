Exercises from first day
