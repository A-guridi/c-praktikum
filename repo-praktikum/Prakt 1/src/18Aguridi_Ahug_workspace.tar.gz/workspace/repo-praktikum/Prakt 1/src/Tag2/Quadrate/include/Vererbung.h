#ifndef VERERBUNG_H
#define VERERBUNG_H


class Vererbung
{
    public:
        Vererbung();
        virtual ~Vererbung();

    protected:

    private:
};

#endif // VERERBUNG_H
