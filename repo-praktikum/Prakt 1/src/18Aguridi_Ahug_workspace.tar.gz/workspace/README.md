# c-praktikum
c++ Praktikum

Arturo Guridi

Alexander Hug

