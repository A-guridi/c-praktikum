#include "Vererbung.h"

Vererbung::Vererbung()
{
    //ctor
}

Vererbung::~Vererbung()
{
    //dtor
}
